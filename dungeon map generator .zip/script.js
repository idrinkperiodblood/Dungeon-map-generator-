const canvas = document.getElementById('dungeonCanvas');
const ctx = canvas.getContext('2d');

const TILE_SIZE = 10;
const ROWS = canvas.height / TILE_SIZE;
const COLS = canvas.width / TILE_SIZE;

let dungeon = [];

function generateDungeon() {
  dungeon = Array.from({ length: ROWS }, () => Array(COLS).fill(0));
  let roomCount = 10;
  let rooms = [];

  // Random rooms
  for (let i = 0; i < roomCount; i++) {
    let room = {
      x: Math.floor(Math.random() * (COLS - 10)),
      y: Math.floor(Math.random() * (ROWS - 10)),
      w: Math.floor(Math.random() * 10) + 5,
      h: Math.floor(Math.random() * 10) + 5
    };
    rooms.push(room);
    carveRoom(room);
  }

  // Connect rooms with corridors
  for (let i = 1; i < rooms.length; i++) {
    let r1 = rooms[i - 1];
    let r2 = rooms[i];
    connectRooms(r1, r2);
  }

  drawDungeon();
}

function carveRoom(room) {
  for (let y = room.y; y < room.y + room.h; y++) {
    for (let x = room.x; x < room.x + room.w; x++) {
      if (x >= 0 && x < COLS && y >= 0 && y < ROWS) {
        dungeon[y][x] = 1;
      }
    }
  }
}

function connectRooms(r1, r2) {
  let x1 = r1.x + Math.floor(r1.w / 2);
  let y1 = r1.y + Math.floor(r1.h / 2);
  let x2 = r2.x + Math.floor(r2.w / 2);
  let y2 = r2.y + Math.floor(r2.h / 2);

  if (Math.random() < 0.5) {
    carveH(x1, x2, y1);
    carveV(y1, y2, x2);
  } else {
    carveV(y1, y2, x1);
    carveH(x1, x2, y2);
  }
}

function carveH(x1, x2, y) {
  for (let x = Math.min(x1, x2); x <= Math.max(x1, x2); x++) {
    if (x >= 0 && x < COLS && y >= 0 && y < ROWS) {
      dungeon[y][x] = 1;
    }
  }
}

function carveV(y1, y2, x) {
  for (let y = Math.min(y1, y2); y <= Math.max(y1, y2); y++) {
    if (x >= 0 && x < COLS && y >= 0 && y < ROWS) {
      dungeon[y][x] = 1;
    }
  }
}

function drawDungeon() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  for (let y = 0; y < ROWS; y++) {
    for (let x = 0; x < COLS; x++) {
      if (dungeon[y][x] === 1) {
        ctx.fillStyle = "#ddd";
        ctx.fillRect(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE);
      }
    }
  }
}

// First map on load
generateDungeon();